import { useEffect } from 'react'
import { createPortal } from 'react-dom'

export default function Modal({ title, onClose, children }) {
  // Prevent page behind from scrolling, but DON'T block body entirely
  // because our modal overlay needs overflow-y-auto to work
  useEffect(() => {
    const main = document.querySelector('main')
    if (main) main.style.overflow = 'hidden'
    return () => {
      if (main) main.style.overflow = ''
    }
  }, [])

  return createPortal(
    <div
      className="fixed inset-0 z-[9999] overflow-y-auto"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" />

      {/* Scroll + centering wrapper */}
      <div className="flex min-h-full items-center justify-center p-4 sm:p-6">

        {/* Dialog card */}
        <div
          className="relative z-10 bg-white rounded-2xl shadow-2xl w-full max-w-lg my-4"
          onClick={e => e.stopPropagation()}
        >
          {/* Sticky header */}
          <div className="flex items-center justify-between px-6 py-4 border-b border-ink-100 sticky top-0 bg-white rounded-t-2xl z-10">
            <h2 className="font-display font-semibold text-ink-900 text-lg">{title}</h2>
            <button
              onClick={onClose}
              className="text-ink-400 hover:text-ink-700 text-2xl leading-none transition-colors cursor-pointer w-8 h-8 flex items-center justify-center rounded-lg hover:bg-ink-100"
            >
              ×
            </button>
          </div>

          {/* Scrollable body */}
          <div className="px-6 py-5">
            {children}
          </div>
        </div>

      </div>
    </div>,
    document.body
  )
}