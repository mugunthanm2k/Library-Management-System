import { NavLink } from 'react-router-dom'
import { useState } from 'react'

const nav = [
  { to: '/dashboard', label: 'Dashboard', icon: '◈' },
  { to: '/books',     label: 'Books',     icon: '◧' },
  { to: '/members',   label: 'Members',   icon: '◉' },
  { to: '/borrows',   label: 'Borrows',   icon: '◫' },
]

export default function Layout({ children }) {
  const [collapsed, setCollapsed] = useState(false)

  return (
    <div className="flex h-screen bg-[#FAFAF9]">

      {/* Sidebar — fixed height, never scrolls */}
      <aside className={`flex flex-col bg-ink-900 text-ink-200 transition-all duration-300 shrink-0 h-screen sticky top-0 ${collapsed ? 'w-16' : 'w-60'}`}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-6 border-b border-ink-700">
          <span className="text-amber-400 text-2xl font-display font-bold shrink-0">𝔅</span>
          {!collapsed && (
            <div>
              <p className="font-display font-semibold text-ink-50 text-base leading-tight">Bibliotheca</p>
              <p className="text-ink-500 text-xs font-mono">Library System</p>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-1 px-3 pt-4 flex-1">
          {nav.map(({ to, label, icon }) => (
            <NavLink
              key={to}
              to={to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-150 text-sm font-medium
                 ${isActive ? 'bg-ink-700 text-ink-50' : 'text-ink-400 hover:bg-ink-800 hover:text-ink-200'}`
              }
            >
              <span className="text-lg shrink-0">{icon}</span>
              {!collapsed && <span>{label}</span>}
            </NavLink>
          ))}
        </nav>

        {/* Collapse toggle */}
        <button
          onClick={() => setCollapsed(c => !c)}
          className="m-3 mt-0 p-2 rounded-lg text-ink-500 hover:text-ink-300 hover:bg-ink-800 transition-all text-xs font-mono text-center cursor-pointer"
        >
          {collapsed ? '→' : '← collapse'}
        </button>
      </aside>

      {/* Main — scrolls independently, NO overflow-hidden */}
      <main className="flex-1 overflow-y-auto overflow-x-hidden">
        <div className="page-enter">
          {children}
        </div>
      </main>

    </div>
  )
}