import { useEffect, useState, useCallback } from 'react'
import { borrowAPI, bookAPI, memberAPI } from '../services/api'
import PageHeader from '../components/PageHeader'
import Modal from '../components/Modal'
import Toast from '../components/Toast'

const STATUS_STYLES = {
  BORROWED: 'bg-amber-100 text-amber-700',
  RETURNED: 'bg-emerald-100 text-emerald-700',
  OVERDUE:  'bg-red-100 text-red-600',
}

export default function Borrows() {
  const [records, setRecords] = useState([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')
  const [showModal, setShowModal] = useState(false)
  const [books, setBooks] = useState([])
  const [members, setMembers] = useState([])
  const [form, setForm] = useState({ bookId: '', memberId: '' })
  const [toast, setToast] = useState(null)
  const [returning, setReturning] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = filter !== 'all' ? { status: filter } : {}
      const res = await borrowAPI.getAll(params)
      setRecords(res.data)
    } catch { setToast({ message: 'Failed to load records', type: 'error' }) }
    finally { setLoading(false) }
  }, [filter])

  useEffect(() => { load() }, [load])

  const openBorrow = async () => {
    try {
      const [booksRes, membersRes] = await Promise.all([bookAPI.getAll(), memberAPI.getAll()])
      setBooks(booksRes.data.filter(b => b.availableCopies > 0))
      setMembers(membersRes.data.filter(m => m.membershipStatus === 'ACTIVE'))
      setForm({ bookId: '', memberId: '' })
      setShowModal(true)
    } catch { setToast({ message: 'Failed to load data', type: 'error' }) }
  }

  const handleBorrow = async (e) => {
    e.preventDefault()
    try {
      await borrowAPI.borrow(+form.bookId, +form.memberId)
      setToast({ message: 'Book borrowed successfully!', type: 'success' })
      setShowModal(false); load()
    } catch (err) { setToast({ message: err.response?.data?.message || 'Error processing borrow', type: 'error' }) }
  }

  const handleReturn = async () => {
    try {
      const res = await borrowAPI.return(returning.id)
      const fine = res.data.fineAmount
      setToast({ message: fine > 0 ? `Returned! Fine: $${fine}` : 'Book returned successfully!', type: 'success' })
      setReturning(null); load()
    } catch (err) { setToast({ message: err.response?.data?.message || 'Error returning book', type: 'error' }) }
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <PageHeader
        title="Borrow Records"
        subtitle={`${records.length} records`}
        action={<button className="btn-primary" onClick={openBorrow}>+ Issue Book</button>}
      />

      {/* Filter tabs */}
      <div className="flex gap-2 mb-6">
        {[['all','All'],['active','Active'],['overdue','Overdue']].map(([val, label]) => (
          <button key={val}
            onClick={() => setFilter(val)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              filter === val ? 'bg-ink-900 text-ink-50' : 'bg-ink-100 text-ink-600 hover:bg-ink-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      <div className="card overflow-x-auto">
        {loading ? (
          <div className="p-12 text-center text-ink-400 font-mono text-sm animate-pulse">Loading records...</div>
        ) : records.length === 0 ? (
          <div className="p-12 text-center text-ink-400 text-sm">No records found.</div>
        ) : (
          <table>
            <thead>
              <tr><th>Book</th><th>Member</th><th>Borrowed</th><th>Due</th><th>Returned</th><th>Status</th><th>Fine</th><th>Action</th></tr>
            </thead>
            <tbody>
              {records.map(r => {
                const isOverdue = r.status === 'OVERDUE' || (r.status === 'BORROWED' && new Date(r.dueDate) < new Date())
                return (
                  <tr key={r.id}>
                    <td>
                      <p className="font-medium text-ink-900">{r.bookTitle}</p>
                      <p className="text-ink-400 font-mono text-xs">{r.bookIsbn}</p>
                    </td>
                    <td>
                      <p className="text-ink-700">{r.memberName}</p>
                      <p className="text-ink-400 text-xs">{r.memberEmail}</p>
                    </td>
                    <td className="font-mono text-xs text-ink-500">{r.borrowedAt ? new Date(r.borrowedAt).toLocaleDateString() : '—'}</td>
                    <td className={`font-mono text-xs ${isOverdue ? 'text-red-600 font-semibold' : 'text-ink-500'}`}>{r.dueDate}</td>
                    <td className="font-mono text-xs text-ink-500">{r.returnedAt ? new Date(r.returnedAt).toLocaleDateString() : '—'}</td>
                    <td>
                      <span className={`tag ${STATUS_STYLES[isOverdue && r.status !== 'RETURNED' ? 'OVERDUE' : r.status]}`}>
                        {isOverdue && r.status !== 'RETURNED' ? 'OVERDUE' : r.status}
                      </span>
                    </td>
                    <td className={`font-mono text-xs ${r.fineAmount > 0 ? 'text-red-600 font-semibold' : 'text-ink-400'}`}>
                      {r.fineAmount > 0 ? `$${r.fineAmount}` : '—'}
                    </td>
                    <td>
                      {r.status !== 'RETURNED' && (
                        <button className="btn-success py-1.5 px-3 text-xs" onClick={() => setReturning(r)}>Return</button>
                      )}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Issue Book Modal */}
      {showModal && (
        <Modal title="Issue Book to Member" onClose={() => setShowModal(false)}>
          <form onSubmit={handleBorrow} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Select Book *</label>
              <select className="input" value={form.bookId} onChange={e => setForm(f => ({ ...f, bookId: e.target.value }))} required>
                <option value="">Choose an available book...</option>
                {books.map(b => (
                  <option key={b.id} value={b.id}>{b.title} — {b.authorName} ({b.availableCopies} left)</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Select Member *</label>
              <select className="input" value={form.memberId} onChange={e => setForm(f => ({ ...f, memberId: e.target.value }))} required>
                <option value="">Choose a member...</option>
                {members.map(m => (
                  <option key={m.id} value={m.id}>{m.name} ({m.email})</option>
                ))}
              </select>
            </div>
            <p className="text-ink-500 text-xs bg-ink-50 rounded-lg p-3">
              📅 Due date will be automatically set to <strong>14 days</strong> from today.
              A fine of $1.00/day applies for overdue books.
            </p>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-primary flex-1">Issue Book</button>
              <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Return Confirm */}
      {returning && (
        <Modal title="Return Book" onClose={() => setReturning(null)}>
          <div className="space-y-3 mb-5">
            <p className="text-ink-600 text-sm">Confirm return of:</p>
            <div className="bg-ink-50 rounded-xl p-4 space-y-1">
              <p className="font-semibold text-ink-900">{returning.bookTitle}</p>
              <p className="text-ink-500 text-sm">Borrowed by: {returning.memberName}</p>
              <p className="text-ink-500 text-sm font-mono">Due: {returning.dueDate}</p>
              {new Date(returning.dueDate) < new Date() && (
                <p className="text-red-600 text-sm font-semibold">⚠ This book is overdue. A fine will be calculated.</p>
              )}
            </div>
          </div>
          <div className="flex gap-3">
            <button className="btn-success flex-1" onClick={handleReturn}>Confirm Return</button>
            <button className="btn-secondary flex-1" onClick={() => setReturning(null)}>Cancel</button>
          </div>
        </Modal>
      )}

      {toast && <Toast {...toast} onClose={() => setToast(null)} />}
    </div>
  )
}