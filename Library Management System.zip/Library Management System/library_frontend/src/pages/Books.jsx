import { useEffect, useState, useCallback } from 'react'
import { bookAPI, authorAPI } from '../services/api'
import PageHeader from '../components/PageHeader'
import Modal from '../components/Modal'
import Toast from '../components/Toast'

const EMPTY_FORM = { title: '', isbn: '', authorId: '', genre: '', publisher: '', publishedYear: '', totalCopies: 1, description: '', coverUrl: '' }

export default function Books() {
  const [books, setBooks] = useState([])
  const [authors, setAuthors] = useState([])
  const [genres, setGenres] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterGenre, setFilterGenre] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(EMPTY_FORM)
  const [toast, setToast] = useState(null)
  const [deleting, setDeleting] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = {}
      if (search) params.search = search
      if (filterGenre) params.genre = filterGenre
      const [booksRes, authorsRes, genresRes] = await Promise.all([
        bookAPI.getAll(params),
        authorAPI.getAll(),
        bookAPI.getGenres(),
      ])
      setBooks(booksRes.data)
      setAuthors(authorsRes.data || [])
      setGenres(genresRes.data || [])
    } catch { setToast({ message: 'Failed to load books', type: 'error' }) }
    finally { setLoading(false) }
  }, [search, filterGenre])

  useEffect(() => { load() }, [load])

  const openCreate = () => { setEditing(null); setForm(EMPTY_FORM); setShowModal(true) }
  const openEdit = (b) => {
    setEditing(b)
    setForm({ title: b.title, isbn: b.isbn, authorId: b.authorId || '', genre: b.genre || '',
      publisher: b.publisher || '', publishedYear: b.publishedYear || '', totalCopies: b.totalCopies,
      description: b.description || '', coverUrl: b.coverUrl || '' })
    setShowModal(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      const payload = { ...form, authorId: form.authorId || null, publishedYear: form.publishedYear ? +form.publishedYear : null, totalCopies: +form.totalCopies }
      if (editing) { await bookAPI.update(editing.id, payload); setToast({ message: 'Book updated!', type: 'success' }) }
      else { await bookAPI.create(payload); setToast({ message: 'Book added!', type: 'success' }) }
      setShowModal(false); load()
    } catch (err) { setToast({ message: err.response?.data?.message || 'Error saving book', type: 'error' }) }
  }

  const handleDelete = async (id) => {
    try { await bookAPI.delete(id); setToast({ message: 'Book deleted', type: 'success' }); setDeleting(null); load() }
    catch (err) { setToast({ message: err.response?.data?.message || 'Cannot delete', type: 'error' }) }
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <PageHeader
        title="Books"
        subtitle={`${books.length} books in catalog`}
        action={<button className="btn-primary" onClick={openCreate}>+ Add Book</button>}
      />

      {/* Filters */}
      <div className="flex gap-3 mb-6 flex-wrap">
        <input className="input max-w-xs" placeholder="Search title or author..." value={search}
          onChange={e => setSearch(e.target.value)} />
        <select className="input max-w-[180px]" value={filterGenre} onChange={e => setFilterGenre(e.target.value)}>
          <option value="">All Genres</option>
          {genres.map(g => <option key={g} value={g}>{g}</option>)}
        </select>
        {(search || filterGenre) && (
          <button className="btn-secondary" onClick={() => { setSearch(''); setFilterGenre('') }}>Clear</button>
        )}
      </div>

      {/* Table */}
      <div className="card overflow-x-auto">
        {loading ? (
          <div className="p-12 text-center text-ink-400 font-mono text-sm animate-pulse">Loading books...</div>
        ) : books.length === 0 ? (
          <div className="p-12 text-center text-ink-400 text-sm">No books found.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Title</th><th>Author</th><th>ISBN</th><th>Genre</th>
                <th>Available</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {books.map(b => (
                <tr key={b.id}>
                  <td>
                    <p className="font-medium text-ink-900">{b.title}</p>
                    {b.publishedYear && <p className="text-ink-400 text-xs font-mono">{b.publishedYear}</p>}
                  </td>
                  <td className="text-ink-600">{b.authorName || '—'}</td>
                  <td className="font-mono text-xs text-ink-500">{b.isbn}</td>
                  <td>{b.genre ? <span className="tag bg-ink-100 text-ink-600">{b.genre}</span> : '—'}</td>
                  <td>
                    <span className={`tag ${b.availableCopies > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-600'}`}>
                      {b.availableCopies}/{b.totalCopies}
                    </span>
                  </td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn-secondary py-1.5 px-3 text-xs" onClick={() => openEdit(b)}>Edit</button>
                      <button className="btn-danger py-1.5 px-3 text-xs" onClick={() => setDeleting(b)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showModal && (
        <Modal title={editing ? 'Edit Book' : 'Add New Book'} onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Title *</label>
              <input className="input" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">ISBN *</label>
                <input className="input" value={form.isbn} onChange={e => setForm(f => ({ ...f, isbn: e.target.value }))} required />
              </div>
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Author</label>
                <select className="input" value={form.authorId} onChange={e => setForm(f => ({ ...f, authorId: e.target.value }))}>
                  <option value="">Select Author</option>
                  {authors.map(a => <option key={a.id} value={a.id}>{a.name}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Genre</label>
                <input className="input" value={form.genre} onChange={e => setForm(f => ({ ...f, genre: e.target.value }))} />
              </div>
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Publisher</label>
                <input className="input" value={form.publisher} onChange={e => setForm(f => ({ ...f, publisher: e.target.value }))} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Year</label>
                <input className="input" type="number" value={form.publishedYear} onChange={e => setForm(f => ({ ...f, publishedYear: e.target.value }))} />
              </div>
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Copies *</label>
                <input className="input" type="number" min="1" value={form.totalCopies} onChange={e => setForm(f => ({ ...f, totalCopies: e.target.value }))} required />
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Description</label>
              <textarea className="input min-h-[80px] resize-none" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-primary flex-1">{editing ? 'Save Changes' : 'Add Book'}</button>
              <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </form>
        </Modal>
      )}

      {/* Delete Confirm */}
      {deleting && (
        <Modal title="Delete Book" onClose={() => setDeleting(null)}>
          <p className="text-ink-600 text-sm mb-5">Are you sure you want to delete <span className="font-semibold text-ink-900">"{deleting.title}"</span>? This action cannot be undone.</p>
          <div className="flex gap-3">
            <button className="btn-danger flex-1" onClick={() => handleDelete(deleting.id)}>Yes, Delete</button>
            <button className="btn-secondary flex-1" onClick={() => setDeleting(null)}>Cancel</button>
          </div>
        </Modal>
      )}

      {toast && <Toast {...toast} onClose={() => setToast(null)} />}
    </div>
  )
}