import { useEffect, useState, useCallback } from 'react'
import { memberAPI } from '../services/api'
import PageHeader from '../components/PageHeader'
import Modal from '../components/Modal'
import Toast from '../components/Toast'

const EMPTY = { name: '', email: '', phone: '', address: '', membershipType: 'BASIC', membershipStatus: 'ACTIVE' }
const TYPE_STYLES = { BASIC: 'bg-ink-100 text-ink-600', PREMIUM: 'bg-amber-100 text-amber-700', STUDENT: 'bg-blue-100 text-blue-700' }
const STATUS_STYLES = { ACTIVE: 'bg-emerald-100 text-emerald-700', SUSPENDED: 'bg-red-100 text-red-600', EXPIRED: 'bg-ink-100 text-ink-500' }

export default function Members() {
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState(EMPTY)
  const [toast, setToast] = useState(null)
  const [deleting, setDeleting] = useState(null)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = search ? { search } : {}
      const res = await memberAPI.getAll(params)
      setMembers(res.data)
    } catch { setToast({ message: 'Failed to load members', type: 'error' }) }
    finally { setLoading(false) }
  }, [search])

  useEffect(() => { load() }, [load])

  const openCreate = () => { setEditing(null); setForm(EMPTY); setShowModal(true) }
  const openEdit = (m) => {
    setEditing(m)
    setForm({ name: m.name, email: m.email, phone: m.phone || '', address: m.address || '',
      membershipType: m.membershipType, membershipStatus: m.membershipStatus })
    setShowModal(true)
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    try {
      if (editing) { await memberAPI.update(editing.id, form); setToast({ message: 'Member updated!', type: 'success' }) }
      else { await memberAPI.create(form); setToast({ message: 'Member added!', type: 'success' }) }
      setShowModal(false); load()
    } catch (err) { setToast({ message: err.response?.data?.message || 'Error saving member', type: 'error' }) }
  }

  const handleDelete = async (id) => {
    try { await memberAPI.delete(id); setToast({ message: 'Member removed', type: 'success' }); setDeleting(null); load() }
    catch (err) { setToast({ message: err.response?.data?.message || 'Cannot delete', type: 'error' }) }
  }

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <PageHeader
        title="Members"
        subtitle={`${members.length} registered members`}
        action={<button className="btn-primary" onClick={openCreate}>+ Add Member</button>}
      />

      <div className="flex gap-3 mb-6">
        <input className="input max-w-xs" placeholder="Search by name..." value={search} onChange={e => setSearch(e.target.value)} />
        {search && <button className="btn-secondary" onClick={() => setSearch('')}>Clear</button>}
      </div>

      <div className="card overflow-x-auto">
        {loading ? (
          <div className="p-12 text-center text-ink-400 font-mono text-sm animate-pulse">Loading members...</div>
        ) : members.length === 0 ? (
          <div className="p-12 text-center text-ink-400 text-sm">No members found.</div>
        ) : (
          <table>
            <thead>
              <tr><th>Name</th><th>Email</th><th>Phone</th><th>Type</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {members.map(m => (
                <tr key={m.id}>
                  <td className="font-medium text-ink-900">{m.name}</td>
                  <td className="text-ink-500 text-xs font-mono">{m.email}</td>
                  <td className="text-ink-500 text-xs">{m.phone || '—'}</td>
                  <td><span className={`tag ${TYPE_STYLES[m.membershipType]}`}>{m.membershipType}</span></td>
                  <td><span className={`tag ${STATUS_STYLES[m.membershipStatus]}`}>{m.membershipStatus}</span></td>
                  <td className="text-ink-400 text-xs font-mono">{m.joinedAt ? new Date(m.joinedAt).toLocaleDateString() : '—'}</td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn-secondary py-1.5 px-3 text-xs" onClick={() => openEdit(m)}>Edit</button>
                      <button className="btn-danger py-1.5 px-3 text-xs" onClick={() => setDeleting(m)}>Remove</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {showModal && (
        <Modal title={editing ? 'Edit Member' : 'Add New Member'} onClose={() => setShowModal(false)}>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Full Name *</label>
              <input className="input" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
            </div>
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Email *</label>
              <input className="input" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} required disabled={!!editing} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Phone</label>
                <input className="input" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
              </div>
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Membership Type</label>
                <select className="input" value={form.membershipType} onChange={e => setForm(f => ({ ...f, membershipType: e.target.value }))}>
                  <option>BASIC</option><option>PREMIUM</option><option>STUDENT</option>
                </select>
              </div>
            </div>
            {editing && (
              <div>
                <label className="block text-xs font-medium text-ink-600 mb-1">Status</label>
                <select className="input" value={form.membershipStatus} onChange={e => setForm(f => ({ ...f, membershipStatus: e.target.value }))}>
                  <option>ACTIVE</option><option>SUSPENDED</option><option>EXPIRED</option>
                </select>
              </div>
            )}
            <div>
              <label className="block text-xs font-medium text-ink-600 mb-1">Address</label>
              <textarea className="input min-h-[70px] resize-none" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
            </div>
            <div className="flex gap-3 pt-2">
              <button type="submit" className="btn-primary flex-1">{editing ? 'Save Changes' : 'Add Member'}</button>
              <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
            </div>
          </form>
        </Modal>
      )}

      {deleting && (
        <Modal title="Remove Member" onClose={() => setDeleting(null)}>
          <p className="text-ink-600 text-sm mb-5">Remove <span className="font-semibold text-ink-900">{deleting.name}</span> from the system?</p>
          <div className="flex gap-3">
            <button className="btn-danger flex-1" onClick={() => handleDelete(deleting.id)}>Yes, Remove</button>
            <button className="btn-secondary flex-1" onClick={() => setDeleting(null)}>Cancel</button>
          </div>
        </Modal>
      )}

      {toast && <Toast {...toast} onClose={() => setToast(null)} />}
    </div>
  )
}