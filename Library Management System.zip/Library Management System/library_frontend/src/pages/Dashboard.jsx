import { useEffect, useState } from 'react'
import { dashboardAPI, borrowAPI } from '../services/api'
import PageHeader from '../components/PageHeader'

const statConfig = [
  { key: 'totalBooks',    label: 'Total Books',     icon: '◧', color: 'text-ink-700',    bg: 'bg-ink-100' },
  { key: 'totalMembers',  label: 'Members',         icon: '◉', color: 'text-blue-700',   bg: 'bg-blue-50' },
  { key: 'activeBorrows', label: 'Active Borrows',  icon: '◫', color: 'text-amber-700',  bg: 'bg-amber-50' },
  { key: 'overdueBooks',  label: 'Overdue',         icon: '⚠', color: 'text-red-700',    bg: 'bg-red-50' },
  { key: 'availableBooks',label: 'Available Books', icon: '✓', color: 'text-emerald-700',bg: 'bg-emerald-50' },
]

export default function Dashboard() {
  const [stats, setStats] = useState(null)
  const [recentBorrows, setRecentBorrows] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([dashboardAPI.getStats(), borrowAPI.getAll({ status: 'active' })])
      .then(([statsRes, borrowsRes]) => {
        setStats(statsRes.data)
        setRecentBorrows(borrowsRes.data.slice(0, 8))
      })
      .finally(() => setLoading(false))
  }, [])

  if (loading) return (
    <div className="p-10 flex items-center justify-center min-h-screen">
      <div className="text-ink-400 font-mono text-sm animate-pulse">Loading dashboard...</div>
    </div>
  )

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <PageHeader
        title="Dashboard"
        subtitle={new Date().toLocaleDateString('en-US', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}
      />

      {/* Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-10">
        {statConfig.map(({ key, label, icon, color, bg }) => (
          <div key={key} className="stat-card">
            <div className={`w-9 h-9 ${bg} ${color} rounded-xl flex items-center justify-center text-base mb-2`}>{icon}</div>
            <p className="text-2xl font-display font-bold text-ink-900">{stats?.[key] ?? 0}</p>
            <p className="text-ink-500 text-xs font-medium">{label}</p>
          </div>
        ))}
      </div>

      {/* Recent Borrows */}
      <div className="card overflow-hidden">
        <div className="px-6 py-4 border-b border-ink-100 flex items-center justify-between">
          <h2 className="font-display font-semibold text-ink-900">Active Borrows</h2>
          <span className="tag bg-amber-100 text-amber-700">{recentBorrows.length} active</span>
        </div>
        {recentBorrows.length === 0 ? (
          <div className="px-6 py-12 text-center text-ink-400 text-sm">No active borrows right now.</div>
        ) : (
          <table>
            <thead>
              <tr>
                <th>Book</th>
                <th>Member</th>
                <th>Borrowed</th>
                <th>Due Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {recentBorrows.map(r => {
                const isOverdue = r.status === 'OVERDUE' || new Date(r.dueDate) < new Date()
                return (
                  <tr key={r.id}>
                    <td className="font-medium text-ink-900">{r.bookTitle}</td>
                    <td className="text-ink-600">{r.memberName}</td>
                    <td className="text-ink-500 font-mono text-xs">{new Date(r.borrowedAt).toLocaleDateString()}</td>
                    <td className={`font-mono text-xs ${isOverdue ? 'text-red-600 font-semibold' : 'text-ink-500'}`}>
                      {r.dueDate}
                    </td>
                    <td>
                      <span className={`tag ${isOverdue ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
                        {isOverdue ? 'OVERDUE' : 'BORROWED'}
                      </span>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}