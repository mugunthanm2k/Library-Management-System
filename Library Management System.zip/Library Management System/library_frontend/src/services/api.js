import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' }
})

// Books
export const bookAPI = {
  getAll: (params) => api.get('/books', { params }),
  getById: (id) => api.get(`/books/${id}`),
  getGenres: () => api.get('/books/genres'),
  create: (data) => api.post('/books', data),
  update: (id, data) => api.put(`/books/${id}`, data),
  delete: (id) => api.delete(`/books/${id}`),
}

// Members
export const memberAPI = {
  getAll: (params) => api.get('/members', { params }),
  getById: (id) => api.get(`/members/${id}`),
  create: (data) => api.post('/members', data),
  update: (id, data) => api.put(`/members/${id}`, data),
  delete: (id) => api.delete(`/members/${id}`),
}

// Borrows
export const borrowAPI = {
  getAll: (params) => api.get('/borrows', { params }),
  getByMember: (memberId) => api.get(`/borrows/member/${memberId}`),
  borrow: (bookId, memberId) => api.post('/borrows/borrow', { bookId, memberId }),
  return: (recordId) => api.put(`/borrows/return/${recordId}`),
}

// Dashboard
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
}

// Authors
export const authorAPI = {
  getAll: () => api.get('/authors'),
}

export default api