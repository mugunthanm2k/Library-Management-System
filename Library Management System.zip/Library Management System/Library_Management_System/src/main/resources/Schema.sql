-- Library Management System - MySQL Schema

CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;

-- Authors table
CREATE TABLE IF NOT EXISTS authors (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    bio TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Books table
CREATE TABLE IF NOT EXISTS books (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    isbn VARCHAR(20) UNIQUE NOT NULL,
    author_id BIGINT,
    genre VARCHAR(100),
    publisher VARCHAR(255),
    published_year INT,
    total_copies INT DEFAULT 1,
    available_copies INT DEFAULT 1,
    description TEXT,
    cover_url VARCHAR(500),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES authors(id) ON DELETE SET NULL
);

-- Members table
CREATE TABLE IF NOT EXISTS members (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    membership_type ENUM('BASIC', 'PREMIUM', 'STUDENT') DEFAULT 'BASIC',
    membership_status ENUM('ACTIVE', 'SUSPENDED', 'EXPIRED') DEFAULT 'ACTIVE',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Borrow records table
CREATE TABLE IF NOT EXISTS borrow_records (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    book_id BIGINT NOT NULL,
    member_id BIGINT NOT NULL,
    borrowed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    due_date DATE NOT NULL,
    returned_at TIMESTAMP NULL,
    status ENUM('BORROWED', 'RETURNED', 'OVERDUE') DEFAULT 'BORROWED',
    fine_amount DECIMAL(10,2) DEFAULT 0.00,
    FOREIGN KEY (book_id) REFERENCES books(id),
    FOREIGN KEY (member_id) REFERENCES members(id)
);

-- Sample data
INSERT INTO authors (name, bio) VALUES
('George Orwell', 'English novelist and essayist, famous for 1984 and Animal Farm.'),
('J.K. Rowling', 'British author, best known for the Harry Potter series.'),
('Yuval Noah Harari', 'Israeli public intellectual and professor of history.'),
('Robert C. Martin', 'Software engineer and author, known as "Uncle Bob".'),
('Eric Evans', 'Software developer and author of Domain-Driven Design.');

INSERT INTO books (title, isbn, author_id, genre, publisher, published_year, total_copies, available_copies, description) VALUES
('1984', '978-0451524935', 1, 'Dystopian Fiction', 'Signet Classic', 1949, 5, 4, 'A chilling dystopia about totalitarian surveillance.'),
('Animal Farm', '978-0451526342', 1, 'Political Satire', 'Signet Classic', 1945, 3, 3, 'A satirical allegory of Soviet totalitarianism.'),
('Harry Potter and the Sorcerer''s Stone', '978-0439708180', 2, 'Fantasy', 'Scholastic', 1997, 8, 6, 'The beginning of the iconic Harry Potter series.'),
('Sapiens', '978-0062316097', 3, 'Non-Fiction', 'Harper', 2011, 4, 3, 'A brief history of humankind.'),
('Clean Code', '978-0132350884', 4, 'Technology', 'Prentice Hall', 2008, 6, 5, 'A handbook of agile software craftsmanship.'),
('Domain-Driven Design', '978-0321125217', 5, 'Technology', 'Addison-Wesley', 2003, 3, 2, 'Tackling complexity in the heart of software.');

INSERT INTO members (name, email, phone, membership_type) VALUES
('Alice Johnson', 'alice@example.com', '555-0101', 'PREMIUM'),
('Bob Smith', 'bob@example.com', '555-0102', 'BASIC'),
('Carol White', 'carol@example.com', '555-0103', 'STUDENT');

INSERT INTO borrow_records (book_id, member_id, due_date, status) VALUES
(1, 1, DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'BORROWED'),
(3, 2, DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'BORROWED');