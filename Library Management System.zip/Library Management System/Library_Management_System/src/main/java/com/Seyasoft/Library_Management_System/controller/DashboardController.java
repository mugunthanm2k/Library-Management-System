package com.Seyasoft.Library_Management_System.controller;

import java.time.LocalDate;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Seyasoft.Library_Management_System.dto.DashboardStatsDTO;
import com.Seyasoft.Library_Management_System.model.BorrowRecord.BorrowStatus;
import com.Seyasoft.Library_Management_System.repository.BookRepository;
import com.Seyasoft.Library_Management_System.repository.BorrowRecordRepository;
import com.Seyasoft.Library_Management_System.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/dashboard")
@RequiredArgsConstructor
public class DashboardController {

    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;
    private final BorrowRecordRepository borrowRecordRepository;

    @GetMapping("/stats")
    public ResponseEntity<DashboardStatsDTO> getStats() {
        long totalBooks = bookRepository.count();
        long totalMembers = memberRepository.count();
        long activeBorrows = borrowRecordRepository.countByStatus(BorrowStatus.BORROWED);
        long overdueBooks = borrowRecordRepository.findOverdueRecords(LocalDate.now()).size();
        long availableBooks = bookRepository.findAvailableBooks().size();

        return ResponseEntity.ok(DashboardStatsDTO.builder()
                .totalBooks(totalBooks)
                .totalMembers(totalMembers)
                .activeBorrows(activeBorrows)
                .overdueBooks(overdueBooks)
                .availableBooks(availableBooks)
                .build());
    }
}