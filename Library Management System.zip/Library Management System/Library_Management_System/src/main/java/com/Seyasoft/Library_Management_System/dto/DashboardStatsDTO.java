package com.Seyasoft.Library_Management_System.dto;



import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class DashboardStatsDTO {
    private long totalBooks;
    private long totalMembers;
    private long activeBorrows;
    private long overdueBooks;
    private long availableBooks;
}