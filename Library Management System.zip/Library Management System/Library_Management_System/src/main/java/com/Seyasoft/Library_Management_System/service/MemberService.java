package com.Seyasoft.Library_Management_System.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Seyasoft.Library_Management_System.dto.MemberDTO;
import com.Seyasoft.Library_Management_System.exception.BadRequestException;
import com.Seyasoft.Library_Management_System.exception.ResourceNotFoundException;
import com.Seyasoft.Library_Management_System.model.Member;
import com.Seyasoft.Library_Management_System.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class MemberService {

    private final MemberRepository memberRepository;

    public List<MemberDTO> getAllMembers() {
        return memberRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public MemberDTO getMemberById(Long id) {
        return toDTO(memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with id: " + id)));
    }

    public List<MemberDTO> searchMembers(String name) {
        return memberRepository.findByNameContainingIgnoreCase(name).stream()
                .map(this::toDTO).collect(Collectors.toList());
    }

    public MemberDTO createMember(MemberDTO dto) {
        if (memberRepository.existsByEmail(dto.getEmail())) {
            throw new BadRequestException("Email already registered: " + dto.getEmail());
        }
        return toDTO(memberRepository.save(fromDTO(dto)));
    }

    public MemberDTO updateMember(Long id, MemberDTO dto) {
        Member member = memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found with id: " + id));
        member.setName(dto.getName());
        member.setPhone(dto.getPhone());
        member.setAddress(dto.getAddress());
        if (dto.getMembershipType() != null) member.setMembershipType(dto.getMembershipType());
        if (dto.getMembershipStatus() != null) member.setMembershipStatus(dto.getMembershipStatus());
        return toDTO(memberRepository.save(member));
    }

    public void deleteMember(Long id) {
        if (!memberRepository.existsById(id)) {
            throw new ResourceNotFoundException("Member not found with id: " + id);
        }
        memberRepository.deleteById(id);
    }

    public MemberDTO toDTO(Member m) {
        return MemberDTO.builder()
                .id(m.getId())
                .name(m.getName())
                .email(m.getEmail())
                .phone(m.getPhone())
                .address(m.getAddress())
                .membershipType(m.getMembershipType())
                .membershipStatus(m.getMembershipStatus())
                .joinedAt(m.getJoinedAt() != null ? m.getJoinedAt().toString() : null)
                .build();
    }

    private Member fromDTO(MemberDTO dto) {
        return Member.builder()
                .name(dto.getName())
                .email(dto.getEmail())
                .phone(dto.getPhone())
                .address(dto.getAddress())
                .membershipType(dto.getMembershipType() != null ? dto.getMembershipType() : Member.MembershipType.BASIC)
                .membershipStatus(Member.MembershipStatus.ACTIVE)
                .build();
    }
}