package com.Seyasoft.Library_Management_System.service;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Seyasoft.Library_Management_System.dto.BorrowRecordDTO;
import com.Seyasoft.Library_Management_System.exception.BadRequestException;
import com.Seyasoft.Library_Management_System.exception.ResourceNotFoundException;
import com.Seyasoft.Library_Management_System.model.Book;
import com.Seyasoft.Library_Management_System.model.BorrowRecord;
import com.Seyasoft.Library_Management_System.model.BorrowRecord.BorrowStatus;
import com.Seyasoft.Library_Management_System.model.Member;
import com.Seyasoft.Library_Management_System.repository.BookRepository;
import com.Seyasoft.Library_Management_System.repository.BorrowRecordRepository;
import com.Seyasoft.Library_Management_System.repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class BorrowService {

    private final BorrowRecordRepository borrowRecordRepository;
    private final BookRepository bookRepository;
    private final MemberRepository memberRepository;

    @Value("${library.fine.per-day:1.00}")
    private BigDecimal finePerDay;

    @Value("${library.borrow.duration-days:14}")
    private int borrowDurationDays;

    public BorrowRecordDTO borrowBook(Long bookId, Long memberId) {
        Book book = bookRepository.findById(bookId)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found"));
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new ResourceNotFoundException("Member not found"));

        if (member.getMembershipStatus() != Member.MembershipStatus.ACTIVE) {
            throw new BadRequestException("Member account is not active.");
        }
        if (book.getAvailableCopies() <= 0) {
            throw new BadRequestException("No copies available for: " + book.getTitle());
        }
        if (borrowRecordRepository.existsByBookIdAndMemberIdAndStatus(bookId, memberId, BorrowStatus.BORROWED)) {
            throw new BadRequestException("Member has already borrowed this book.");
        }

        book.setAvailableCopies(book.getAvailableCopies() - 1);
        bookRepository.save(book);

        BorrowRecord record = BorrowRecord.builder()
                .book(book)
                .member(member)
                .dueDate(LocalDate.now().plusDays(borrowDurationDays))
                .status(BorrowStatus.BORROWED)
                .fineAmount(BigDecimal.ZERO)
                .build();

        return toDTO(borrowRecordRepository.save(record));
    }

    public BorrowRecordDTO returnBook(Long recordId) {
        BorrowRecord record = borrowRecordRepository.findById(recordId)
                .orElseThrow(() -> new ResourceNotFoundException("Borrow record not found"));

        if (record.getStatus() == BorrowStatus.RETURNED) {
            throw new BadRequestException("Book already returned.");
        }

        record.setReturnedAt(LocalDateTime.now());
        record.setStatus(BorrowStatus.RETURNED);

        // Calculate fine if overdue
        if (LocalDate.now().isAfter(record.getDueDate())) {
            long daysOverdue = ChronoUnit.DAYS.between(record.getDueDate(), LocalDate.now());
            record.setFineAmount(finePerDay.multiply(BigDecimal.valueOf(daysOverdue)));
        }

        Book book = record.getBook();
        book.setAvailableCopies(book.getAvailableCopies() + 1);
        bookRepository.save(book);

        return toDTO(borrowRecordRepository.save(record));
    }

    public List<BorrowRecordDTO> getAllBorrows() {
        return borrowRecordRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<BorrowRecordDTO> getBorrowsByMember(Long memberId) {
        return borrowRecordRepository.findByMemberId(memberId).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<BorrowRecordDTO> getActiveBorrows() {
        return borrowRecordRepository.findByStatus(BorrowStatus.BORROWED).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<BorrowRecordDTO> getOverdueBorrows() {
        // Update statuses first
        List<BorrowRecord> overdue = borrowRecordRepository.findOverdueRecords(LocalDate.now());
        overdue.forEach(r -> r.setStatus(BorrowStatus.OVERDUE));
        borrowRecordRepository.saveAll(overdue);
        return overdue.stream().map(this::toDTO).collect(Collectors.toList());
    }

    public BorrowRecordDTO toDTO(BorrowRecord r) {
        return BorrowRecordDTO.builder()
                .id(r.getId())
                .bookId(r.getBook().getId())
                .bookTitle(r.getBook().getTitle())
                .bookIsbn(r.getBook().getIsbn())
                .memberId(r.getMember().getId())
                .memberName(r.getMember().getName())
                .memberEmail(r.getMember().getEmail())
                .borrowedAt(r.getBorrowedAt() != null ? r.getBorrowedAt().toString() : null)
                .dueDate(r.getDueDate() != null ? r.getDueDate().toString() : null)
                .returnedAt(r.getReturnedAt() != null ? r.getReturnedAt().toString() : null)
                .status(r.getStatus())
                .fineAmount(r.getFineAmount())
                .build();
    }
}