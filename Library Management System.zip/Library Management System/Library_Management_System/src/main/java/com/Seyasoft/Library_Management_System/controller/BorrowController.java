package com.Seyasoft.Library_Management_System.controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Seyasoft.Library_Management_System.dto.BorrowRecordDTO;
import com.Seyasoft.Library_Management_System.service.BorrowService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/borrows")
@RequiredArgsConstructor
public class BorrowController {

    private final BorrowService borrowService;

    @GetMapping
    public ResponseEntity<List<BorrowRecordDTO>> getAll(
            @RequestParam(required = false) String status) {
        if ("active".equalsIgnoreCase(status)) return ResponseEntity.ok(borrowService.getActiveBorrows());
        if ("overdue".equalsIgnoreCase(status)) return ResponseEntity.ok(borrowService.getOverdueBorrows());
        return ResponseEntity.ok(borrowService.getAllBorrows());
    }

    @GetMapping("/member/{memberId}")
    public ResponseEntity<List<BorrowRecordDTO>> getByMember(@PathVariable Long memberId) {
        return ResponseEntity.ok(borrowService.getBorrowsByMember(memberId));
    }

    @PostMapping("/borrow")
    public ResponseEntity<BorrowRecordDTO> borrowBook(@RequestBody Map<String, Long> request) {
        Long bookId = request.get("bookId");
        Long memberId = request.get("memberId");
        return ResponseEntity.status(HttpStatus.CREATED).body(borrowService.borrowBook(bookId, memberId));
    }

    @PutMapping("/return/{recordId}")
    public ResponseEntity<BorrowRecordDTO> returnBook(@PathVariable Long recordId) {
        return ResponseEntity.ok(borrowService.returnBook(recordId));
    }
}