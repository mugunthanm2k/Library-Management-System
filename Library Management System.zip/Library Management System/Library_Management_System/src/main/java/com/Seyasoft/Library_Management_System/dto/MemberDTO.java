package com.Seyasoft.Library_Management_System.dto;


import com.Seyasoft.Library_Management_System.model.Member.MembershipStatus;
import com.Seyasoft.Library_Management_System.model.Member.MembershipType;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class MemberDTO {
    private Long id;

    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email")
    private String email;

    private String phone;
    private String address;
    private MembershipType membershipType;
    private MembershipStatus membershipStatus;
    private String joinedAt;
}
