package com.Seyasoft.Library_Management_System.dto;


import java.math.BigDecimal;

import com.Seyasoft.Library_Management_System.model.BorrowRecord.BorrowStatus;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class BorrowRecordDTO {
    private Long id;

    @NotNull(message = "Book ID is required")
    private Long bookId;

    private String bookTitle;
    private String bookIsbn;

    @NotNull(message = "Member ID is required")
    private Long memberId;

    private String memberName;
    private String memberEmail;
    private String borrowedAt;
    private String dueDate;
    private String returnedAt;
    private BorrowStatus status;
    private BigDecimal fineAmount;
}