package com.Seyasoft.Library_Management_System.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Seyasoft.Library_Management_System.model.Member;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {
    Optional<Member> findByEmail(String email);
    List<Member> findByNameContainingIgnoreCase(String name);
    boolean existsByEmail(String email);
    List<Member> findByMembershipStatus(Member.MembershipStatus status);
}
