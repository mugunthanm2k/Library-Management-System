package com.Seyasoft.Library_Management_System.dto;
import jakarta.validation.constraints.*;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class BookDTO {
    private Long id;

    @NotBlank(message = "Title is required")
    private String title;

    @NotBlank(message = "ISBN is required")
    private String isbn;

    private Long authorId;
    private String authorName;
    private String genre;
    private String publisher;
    private Integer publishedYear;

    @Min(value = 1, message = "Total copies must be at least 1")
    private Integer totalCopies;

    private Integer availableCopies;
    private String description;
    private String coverUrl;
}
