package com.Seyasoft.Library_Management_System.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.Seyasoft.Library_Management_System.model.BorrowRecord;
import com.Seyasoft.Library_Management_System.model.BorrowRecord.BorrowStatus;

@Repository
public interface BorrowRecordRepository extends JpaRepository<BorrowRecord, Long> {
    List<BorrowRecord> findByMemberId(Long memberId);
    List<BorrowRecord> findByBookId(Long bookId);
    List<BorrowRecord> findByStatus(BorrowStatus status);

    @Query("SELECT br FROM BorrowRecord br WHERE br.status = 'BORROWED' AND br.dueDate < :today")
    List<BorrowRecord> findOverdueRecords(LocalDate today);

    boolean existsByBookIdAndMemberIdAndStatus(Long bookId, Long memberId, BorrowStatus status);

    long countByStatus(BorrowStatus status);
}
