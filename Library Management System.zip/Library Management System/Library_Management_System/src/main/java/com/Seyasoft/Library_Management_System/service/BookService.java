package com.Seyasoft.Library_Management_System.service;


import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Seyasoft.Library_Management_System.dto.BookDTO;
import com.Seyasoft.Library_Management_System.exception.BadRequestException;
import com.Seyasoft.Library_Management_System.exception.ResourceNotFoundException;
import com.Seyasoft.Library_Management_System.model.Author;
import com.Seyasoft.Library_Management_System.model.Book;
import com.Seyasoft.Library_Management_System.repository.AuthorRepository;
import com.Seyasoft.Library_Management_System.repository.BookRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
@Transactional
public class BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;

    public List<BookDTO> getAllBooks() {
        return bookRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
    }

    public BookDTO getBookById(Long id) {
        return toDTO(bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id)));
    }

    public List<BookDTO> searchBooks(String query) {
        List<Book> byTitle = bookRepository.findByTitleContainingIgnoreCase(query);
        List<Book> byAuthor = bookRepository.findByAuthor_NameContainingIgnoreCase(query);
        byTitle.addAll(byAuthor.stream()
                .filter(b -> byTitle.stream().noneMatch(t -> t.getId().equals(b.getId())))
                .collect(Collectors.toList()));
        return byTitle.stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<BookDTO> getBooksByGenre(String genre) {
        return bookRepository.findByGenreIgnoreCase(genre).stream().map(this::toDTO).collect(Collectors.toList());
    }

    public List<String> getAllGenres() {
        return bookRepository.findAllGenres();
    }

    public BookDTO createBook(BookDTO dto) {
        if (bookRepository.existsByIsbn(dto.getIsbn())) {
            throw new BadRequestException("A book with ISBN " + dto.getIsbn() + " already exists.");
        }
        Book book = fromDTO(dto);
        return toDTO(bookRepository.save(book));
    }

    public BookDTO updateBook(Long id, BookDTO dto) {
        Book book = bookRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Book not found with id: " + id));
        book.setTitle(dto.getTitle());
        book.setIsbn(dto.getIsbn());
        book.setGenre(dto.getGenre());
        book.setPublisher(dto.getPublisher());
        book.setPublishedYear(dto.getPublishedYear());
        book.setTotalCopies(dto.getTotalCopies());
        book.setDescription(dto.getDescription());
        book.setCoverUrl(dto.getCoverUrl());
        if (dto.getAuthorId() != null) {
            Author author = authorRepository.findById(dto.getAuthorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Author not found"));
            book.setAuthor(author);
        }
        return toDTO(bookRepository.save(book));
    }

    public void deleteBook(Long id) {
        if (!bookRepository.existsById(id)) {
            throw new ResourceNotFoundException("Book not found with id: " + id);
        }
        bookRepository.deleteById(id);
    }

    public BookDTO toDTO(Book b) {
        return BookDTO.builder()
                .id(b.getId())
                .title(b.getTitle())
                .isbn(b.getIsbn())
                .authorId(b.getAuthor() != null ? b.getAuthor().getId() : null)
                .authorName(b.getAuthor() != null ? b.getAuthor().getName() : null)
                .genre(b.getGenre())
                .publisher(b.getPublisher())
                .publishedYear(b.getPublishedYear())
                .totalCopies(b.getTotalCopies())
                .availableCopies(b.getAvailableCopies())
                .description(b.getDescription())
                .coverUrl(b.getCoverUrl())
                .build();
    }

    private Book fromDTO(BookDTO dto) {
        Author author = null;
        if (dto.getAuthorId() != null) {
            author = authorRepository.findById(dto.getAuthorId()).orElse(null);
        }
        return Book.builder()
                .title(dto.getTitle())
                .isbn(dto.getIsbn())
                .author(author)
                .genre(dto.getGenre())
                .publisher(dto.getPublisher())
                .publishedYear(dto.getPublishedYear())
                .totalCopies(dto.getTotalCopies() != null ? dto.getTotalCopies() : 1)
                .availableCopies(dto.getTotalCopies() != null ? dto.getTotalCopies() : 1)
                .description(dto.getDescription())
                .coverUrl(dto.getCoverUrl())
                .build();
    }
}